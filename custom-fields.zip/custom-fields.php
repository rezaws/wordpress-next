<?php
/**
 * Plugin Name: Custom Job Manager Fields
 */

// جلوگیری از دسترسی مستقیم


// ==================== ایجاد منو در پیشخوان ====================
add_action('admin_menu', 'register_custom_fields_admin_menu');

function register_custom_fields_admin_menu() {
    add_menu_page(
        'فیلدهای خصوصی',           // عنوان صفحه
        'فیلدهای خصوصی',           // عنوان منو
        'manage_options',           // capability مورد نیاز
        'custom-job-fields',        // slug منو
        'render_custom_fields_page', // تابع نمایش صفحه
        'dashicons-admin-generic',  // آیکون
        30                          // موقعیت در منو
    );
}

// ==================== صفحه مدیریت فیلدها ====================
function render_custom_fields_page() {
    // ذخیره‌سازی فیلدها اگر فرم ارسال شده
    if (isset($_POST['submit_custom_field'])) {
        save_custom_field();
    }
    
    // حذف فیلد اگر درخواست شده
    if (isset($_GET['delete_field'])) {
        delete_custom_field($_GET['delete_field']);
    }
    
    // دریافت همه فیلدهای ذخیره شده
    $saved_fields = get_option('custom_job_fields', array());
    ?>
    
    <div class="wrap">
        <h1>مدیریت فیلدهای خصوصی</h1>
        
        <!-- فرم افزودن فیلد جدید -->
        <div style="background: #fff; padding: 20px; margin: 20px 0; border-radius: 5px;">
            <h2>افزودن فیلد جدید</h2>
            <form method="post">
                <?php wp_nonce_field('custom_field_nonce', 'field_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th><label for="field_name">نام فیلد (انگلیسی)</label></th>
                        <td>
                            <input type="text" name="field_name" required 
                                   placeholder="مثال: custom_salary" style="width: 300px;">
                            <p class="description">فقط حروف انگلیسی و underline مجاز است</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="field_label">برچسب فارسی</label></th>
                        <td>
                            <input type="text" name="field_label" required 
                                   placeholder="مثال: حقوق" style="width: 300px;">
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="field_type">نوع فیلد</label></th>
                        <td>
                            <select name="field_type" style="width: 300px;">
                                <option value="text">متنی</option>
                                <option value="textarea">متن بلند</option>
                                <option value="checkbox">چک‌باکس</option>
                                <option value="select">لیست dropdown</option>
                            </select>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="field_required">اجباری؟</label></th>
                        <td>
                            <input type="checkbox" name="field_required" value="1">
                        </td>
                    </tr>
                </table>
                
                <?php submit_button('ذخیره فیلد', 'primary', 'submit_custom_field'); ?>
            </form>
        </div>
        
        <!-- لیست فیلدهای موجود -->
        <div style="background: #fff; padding: 20px; border-radius: 5px;">
            <h2>فیلدهای موجود</h2>
            
            <?php if (empty($saved_fields)) : ?>
                <p>هنوز فیلدی ایجاد نشده است.</p>
            <?php else : ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>نام فیلد</th>
                            <th>برچسب</th>
                            <th>نوع</th>
                            <th>اجباری</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($saved_fields as $field) : ?>
                            <tr>
                                <td><?php echo esc_html($field['name']); ?></td>
                                <td><?php echo esc_html($field['label']); ?></td>
                                <td><?php echo esc_html($field['type']); ?></td>
                                <td><?php echo $field['required'] ? '✅' : '❌'; ?></td>
                                <td>
                                    <a href="?page=custom-job-fields&delete_field=<?php echo $field['name']; ?>" 
                                       onclick="return confirm('آیا مطمئن هستید؟')" 
                                       style="color: #dc3232;">حذف</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
    <?php
}

// ==================== توابع کمکی ====================
function save_custom_field() {
    // بررسی nonce و permissions
    if (!wp_verify_nonce($_POST['field_nonce'], 'custom_field_nonce') || !current_user_can('manage_options')) {
        return;
    }
    
    $field_name = sanitize_text_field($_POST['field_name']);
    $field_label = sanitize_text_field($_POST['field_label']);
    $field_type = sanitize_text_field($_POST['field_type']);
    $field_required = isset($_POST['field_required']) ? 1 : 0;
    
    // دریافت فیلدهای موجود
    $saved_fields = get_option('custom_job_fields', array());
    
    // اضافه کردن فیلد جدید
    $saved_fields[$field_name] = array(
        'name' => $field_name,
        'label' => $field_label,
        'type' => $field_type,
        'required' => $field_required
    );
    
    // ذخیره در options
    update_option('custom_job_fields', $saved_fields);
    
    echo '<div class="notice notice-success"><p>فیلد با موفقیت ذخیره شد!</p></div>';
}

function delete_custom_field($field_name) {
    if (!current_user_can('manage_options')) {
        return;
    }
    
    $saved_fields = get_option('custom_job_fields', array());
    
    if (isset($saved_fields[$field_name])) {
        unset($saved_fields[$field_name]);
        update_option('custom_job_fields', $saved_fields);
        
        echo '<div class="notice notice-success"><p>فیلد با موفقیت حذف شد!</p></div>';
    }
}

// ==================== ایجاد فیلدها در فرم Job Manager ====================
add_filter('submit_job_form_fields', 'add_dynamic_custom_fields');

function add_dynamic_custom_fields($fields) {
    $saved_fields = get_option('custom_job_fields', array());
    
    foreach ($saved_fields as $field) {
        $fields['job'][$field['name']] = array(
            'label' => $field['label'],
            'type' => $field['type'],
            'required' => $field['required'],
            'placeholder' => '',
            'priority' => 10
        );
    }
    
    return $fields;
}

// ==================== ذخیره‌سازی فیلدهای داینامیک ====================
add_action('job_manager_update_job_data', 'save_dynamic_custom_fields', 10, 2);

function save_dynamic_custom_fields($job_id, $values) {
    $saved_fields = get_option('custom_job_fields', array());
    
    foreach ($saved_fields as $field) {
        $field_name = $field['name'];
        
        if (isset($values['job'][$field_name])) {
            update_post_meta($job_id, '_' . $field_name, sanitize_text_field($values['job'][$field_name]));
        }
    }
}


// ==================== ثبت فیلدهای سفارشی در REST API ====================
add_action('rest_api_init', 'register_custom_fields_in_rest_api');

function register_custom_fields_in_rest_api() {
    $saved_fields = get_option('custom_job_fields', array());
    
    foreach ($saved_fields as $field) {
        $field_name = $field['name'];
        
        register_rest_field('job_listing', $field_name, array(
            'get_callback' => function($object) use ($field_name) {
                return get_post_meta($object['id'], '_' . $field_name, true);
            },
            'update_callback' => function($value, $object) use ($field_name) {
                update_post_meta($object->ID, '_' . $field_name, sanitize_text_field($value));
            },
            'schema' => array(
                'type' => 'string',
                'description' => $field['label'],
            ),
        ));
    }
}

// ==================== اضافه کردن فیلدها به پاسخ اصلی API ====================
add_filter('rest_prepare_job_listing', 'add_custom_fields_to_rest_response', 10, 3);

function add_custom_fields_to_rest_response($response, $post, $request) {
    $saved_fields = get_option('custom_job_fields', array());
    
    foreach ($saved_fields as $field) {
        $field_name = $field['name'];
        $value = get_post_meta($post->ID, '_' . $field_name, true);
        
        // اضافه کردن به بخش meta پاسخ
        $response->data['meta'][$field_name] = $value;
    }
    
    return $response;
}