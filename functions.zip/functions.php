<?php 

use Firebase\JWT\JWT;
use Firebase\JWT\Key;


/*
Plugin Name: Gholly Functions
Description: Custom REST endpoint for user registration
Version: 1.0
Author: Gholly
*/

require_once dirname(__DIR__) . '/vendor/autoload.php';

require_once plugin_dir_path(__FILE__) . 'inc/custom-fields.php';
require_once plugin_dir_path(__FILE__) . 'inc/post-types.php';
require_once plugin_dir_path(__FILE__) . 'inc/category-icon.php';


/* User Registeration Endpoint ------------------------ */

add_action('rest_api_init', function () {
  register_rest_route('next/users', 'register', [
    'methods'  => 'POST',
    'callback' => 'gholly_user_register_handler',
    'permission_callback' => fn() => is_user_logged_in()
  ]);
});


/* User Login Endpoint -------------------------- */

add_action('rest_api_init', function () {
  register_rest_route('next/users', '/login', [
    'methods' => 'POST',
    'callback' => 'gholly_login_handler',
    'permission_callback' => fn() => is_user_logged_in()
  ]);
});


/* Refresh Token Handler ------------------------------------ */

add_action( 'rest_api_init', function() {
  register_rest_route( 'next/users', 'ref-token', [
    'method'   => 'POST',
    'callback' => 'gholly_refresh_token_handler',
    'permission_callback' => fn() => is_user_logged_in()
  ]);
});


add_action('rest_api_init', function () {
  register_rest_route('next/users', '/create-ads', [
    'methods' => 'POST',
    'callback' => 'create_ads_handler',
    'permission_callback' => fn() => is_user_logged_in()
  ]);
});


/* Register Handler ---------------------------- */
function gholly_user_register_handler($request) {
  $params   = $request->get_json_params();
  $username = sanitize_user($params['username']);
  $email    = sanitize_email($params['email']);
  $password = sanitize_text_field($params['password']);
  $role     = sanitize_text_field($params['role'] ?? 'author'); // نقش پیش‌فرض

  // اعتبارسنجی اولیه
  if (!$username || !$email || !$password) {
    return new WP_Error('missing_fields', 'همه‌ی فیلدها الزامی هستند.', ['status' => 400]);
  }

  // بررسی وجود یوزرنیم یا ایمیل
  if (username_exists($username)) {
    return new WP_Error('username_exists', 'نام کاربری قبلاً ثبت شده.', ['status' => 409]);
  }

  if (email_exists($email)) {
    return new WP_Error('email_exists', 'ایمیل قبلاً ثبت شده.', ['status' => 409]);
  }

  // ساخت کاربر
  $user_id = wp_create_user($username, $password, $email);

  if (is_wp_error($user_id)) {
    return new WP_Error('registration_failed', 'ثبت‌نام انجام نشد.', ['status' => 500]);
  }

  // ست کردن نقش
  $user = get_user_by('id', $user_id);
  if ($user && in_array($role, ['author', 'subscriber', 'editor'])) {
    $user->set_role($role);
  }

  $token = gholly_generate_jwt($user->ID);

  return [
    'token'   => $token,
    'user_id' => $user_id,
    'message' => 'ثبت‌نام با موفقیت انجام شد',
    'role'    => $role,
  ];
}


/* Login Handler -------------------------------------------- */

function gholly_login_handler($request) {
  $params   = $request->get_json_params();
  $username = sanitize_user($params['username'] ?? '');
  $password = sanitize_text_field($params['password'] ?? '');

  if (!$username || !$password) {
    return new WP_Error('missing_fields', 'نام کاربری و رمز عبور الزامی هستند.', ['status' => 400]);
  }

  $user = wp_authenticate($username, $password);

  if (is_wp_error($user)) {
    return new WP_Error('invalid_credentials', 'نام کاربری یا رمز عبور اشتباه است.', ['status' => 403]);
  }

  // ساخت توکن JWT
  $secret_key = JWT_AUTH_SECRET_KEY; // حتماً قوی باشه و در wp-config.php ذخیره بشه
  $issuedAt   = time();
  $expire     = $issuedAt + DAY_IN_SECONDS * 20;

  $payload = [
    'iat'  => $issuedAt,
    'exp'  => $expire,
    'user' => [
      'id'    => $user->ID,
      'email' => $user->user_email,
      'role'  => $user->roles[0],
      'username' => $user->user_login,
    ],
  ];

  // استفاده از کلاس JWT از firebase/php-jwt
  $token = JWT::encode($payload, $secret_key, 'HS256');

  return [
    'token'   => $token,
    'user_id' => $user->ID,
    'role'    => $user->roles[0],
    'email' =>   $user->user_email,
    'message' => 'ورود موفقیت‌آمیز بود',
  ];
}


/* Refresh Token Handler Function ----------------------------------- */

function  gholly_refresh_token_handler($request) {
    $auth = $request->get_header('authorization');
    $secret_key = JWT_AUTH_SECRET_KEY;
    $access_token = str_replace('Bearer ', '', $auth);

    if (!$auth || !str_starts_with($auth, 'Bearer ')) {
      return new WP_Error('no_token', 'توکن ارسال نشده.', ['status' => 401]);
    }

  try {
    $decoded = JWT::decode($access_token, new \Firebase\JWT\Key($secret_key, 'HS256'));
    $user_id = $decoded->user_id;
    $issuedAt = $decoded->iat;

    // بررسی اینکه آیا بیشتر از ۷ دقیقه گذشته؟
    if (time() - $issuedAt > 850) { // 15 دقیقه
      // ساخت Refresh Token جدید
      $new_refresh_payload = [
        'iat' => time(),
        'exp' => time() + 850,
        'user_id' => $user_id,
      ];
      $new_refresh_token = JWT::encode($new_refresh_payload, $secret_key, 'HS256');
      update_user_meta($user_id, '_gholly_refresh_token', $new_refresh_token);
    }

    // ساخت Access Token جدید
    $user = get_userdata($user_id);
    $access_payload = [
      'iat' => time(),
      'exp' => time() + 300,
      'user' => [
        'id' => $user->ID,
        'email' => $user->user_email,
        'role' => $user->roles[0],
      ],
    ];
    $access_token = JWT::encode($access_payload, $secret_key, 'HS256');

    return [
      'wp_token' => $access_token,
      'wp-ref_token' => $new_refresh_token ?? $access_token,
    ];
  } catch (Exception $e) {
    return new WP_Error('invalid_token', 'توکن نامعتبر یا منقضی شده', ['status' => 403]);
  }
}


/*  JWT ----- Composer -------------------------------------- */
function gholly_generate_jwt($user_id) {
  $secret_key = JWT_AUTH_SECRET_KEY; // حتماً قوی باشه
  $issuedAt   = time();
  $expire     = $issuedAt + DAY_IN_SECONDS * 7; // اعتبار ۷ روزه

  $user = get_userdata($user_id);

  $payload = [
    'iat'  => $issuedAt,
    'exp'  => $expire,
    'user' => [
      'id'    => $user->ID,
      'email' => $user->user_email,
      'role'  => $user->roles[0],
    ],
  ];

  return JWT::encode($payload, $secret_key, 'HS256');
}


/* Validate User Token  ------------------------------------*/

function validate_user_token() {
  // فرض بر اینه که توکن توی کوکی با نام 'jwt_token' ذخیره شده
  $token = $_COOKIE['wp-token'] ?? null;

  if (!$token) {
    return false;
  }

  try {
    // دیکود کردن توکن با کلید مخفی
    $secret_key = JWT_AUTH_SECRET_KEY; // همون کلیدی که باهاش توکن رو ساختی
    $decoded = JWT::decode($token, new Key($secret_key, 'HS256'));

    // گرفتن user_id از توکن
    $user_id = $decoded->user_id ?? null;

    if ($user_id && get_userdata($user_id)) {
      return 
        $user_id;
    }
  } catch (Exception $e) {
    // اگر توکن نامعتبر یا منقضی شده باشه
    return false;
  }

  return false;
}



/* Create Ads Handler --------------------------- */

function create_ad_handler($request) {
  $params = $request->get_json_params();

  $user_id = validate_user_token();
  
  if (!$user_id) {
    return new WP_Error('unauthorized', 'کاربر معتبر نیست', ['status' => 401]);
  }

  $post_data = [
    'post_title'   => sanitize_text_field($params['title']),
    'post_content' => sanitize_textarea_field($params['content']),
    'post_status'  => 'publish',
    'post_type'    => 'ads',
    'post_author'  => $user_id
  ];

  $post_id = wp_insert_post($post_data);

  if (is_wp_error($post_id)) {
    return new WP_Error('insert_failed', 'ثبت آگهی ناموفق بود', ['status' => 500]);
  }

  // ذخیره فیلدهای پکیج
  if (!empty($params['meta'])) {
    foreach ($params['meta'] as $key => $value) {
      update_post_meta($post_id, $key, sanitize_text_field($value));
    }
  }

  return [
    'success' => true,
    'post_id' => $post_id
  ];
}

//------------------------------------------------------------
//------------------------------------------------------------

function test_login_handler($request) {
    $params = $request->get_json_params();
    $username = sanitize_user($params['username'] ?? '');
    $password = sanitize_text_field($params['password'] ?? '');
    
    // بررسی وجود username و password
    if (empty($username) || empty($password)) {
        return new WP_Error('missing_data', 'نام کاربری و رمز عبور الزامی هستند', ['status' => 400]);
    }
    
    // احراز هویت کاربر
    $user = wp_authenticate($username, $password);
    
    if (is_wp_error($user)) {
        return new WP_Error('auth_failed', 'نام کاربری یا رمز عبور نادرست است', ['status' => 401]);
    }
    
  $secret_key = JWT_AUTH_SECRET_KEY; // حتماً قوی باشه و در wp-config.php ذخیره بشه
 // $issuedAt   = time();
 // $expire     = $issuedAt + DAY_IN_SECONDS * 20;

  $payload = [
    'user' => [
      'id'    => $user->ID,
      'email' => $user->user_email,
      'role'  => $user->roles[0],
    ],
  ];

  // استفاده از کلاس JWT از firebase/php-jwt
   $token = JWT::encode($payload, $secret_key, 'HS256');

return rest_ensure_response([ 
  'token' => $token,
  'user_id' => $user->ID,
  'email' => $user->user_email,
  'role' => $user->roles[0], 
  'message' => 'ورود موفقیت‌آمیز بود', ]);
}
add_action('rest_api_init', function () {
  register_rest_route('next/users', '/logins', [
    'methods' => 'POST',
    'callback' => 'test_login_handler',
    'permission_callback' => '__return_true'
  ]);
});


add_action('rest_api_init', function () {
  register_rest_route('next/users', '/create-adis', [
    'methods' => 'POST',
    'callback' => 'test_adis_handler',
    'permission_callback' => 'valid_user_token'
  ]);
});

function test_adis_handler($request) {
$params = $request->get_json_params();

  $post_id = wp_insert_post([
    'post_title' => sanitize_text_field($params['title']),
    'post_content' => sanitize_textarea_field($params['content']),
    'post_type' => 'adis',
    'post_status' => 'publish',
  ]);

  if (is_wp_error($post_id)) {
    return new WP_Error('create_failed', 'خطا در ایجاد آگهی', ['status' => 500]);
  }

  // ذخیره فیلدهای متا
  $meta_fields = [
    '_adis_tags',
    '_adis_category',
    '_adis_email',
    '_adis_ads_id',
  ];

  foreach ($meta_fields as $field) {
    if (isset($params[$field])) {
      update_post_meta($post_id, $field, sanitize_text_field($params[$field]));
    }
  }

  return rest_ensure_response([
    'success' => true,
    'post_id' => $post_id,
  ]);
}

// Verfiy User Permission----------------------------------------------

function valid_user_token() {
  $headers = getallheaders();
  $authHeader = $headers['Authorization'] ?? '';

  if (strpos($authHeader, 'Bearer ') !== 0) {
    return false;
  }

  $token = substr($authHeader, 7);
  $secret = JWT_AUTH_SECRET_KEY; // همونی که باهاش توکن رو ساختی

  try {
    $decoded = JWT::decode($token, new Key($secret, 'HS256'));
    $user_id = $decoded->user->id ?? null;

    // اینجا می‌تونی نقش یا سطح دسترسی رو هم چک کنی
    return !empty($user_id);
  } catch (Exception $e) {
    error_log('توکن نامعتبر: ' . $e->getMessage());
    return false;
  }
}
